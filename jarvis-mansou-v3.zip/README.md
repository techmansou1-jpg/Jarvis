# 🤖 JARVIS — Assistant Personnel de Mansou

> Assistant IA personnel propulsé par Claude AI  
> Projet de Suleman Abdul Lhai Olakunle (Mansou)

---

## 🌐 URL en ligne
**[jarvis-mansou.vercel.app](https://jarvis-mansou.vercel.app)**

---

## 🚀 Stack technique
- **Frontend** : HTML / CSS / JavaScript (vanilla)
- **IA** : Claude Sonnet via Anthropic API
- **Voix** : Web Speech API (reconnaissance + synthèse)
- **Hébergement** : Vercel (déploiement automatique)
- **Versioning** : GitHub

---

## 📦 Structure du projet
```
jarvis-mansou/
├── index.html       → Interface principale JARVIS
├── vercel.json      → Configuration déploiement Vercel
└── README.md        → Documentation & changelog
```

---

## 📋 Changelog

### v2.0 — Vocal
- ✅ Reconnaissance vocale (mic → texte)
- ✅ Synthèse vocale (JARVIS parle)
- ✅ Toggle auto-speak ON/OFF
- ✅ Bouton réécouter sur chaque message

### v1.0 — Lancement
- ✅ Interface JARVIS style Iron Man / HUD
- ✅ Chat IA propulsé par Claude
- ✅ JARVIS connaît Mansou, E.I.E., TechMansou
- ✅ Optimisé mobile

---

## 🔮 Roadmap
- [ ] v3.0 — Gestion de tâches vocale
- [ ] v3.1 — Commandes rapides (EIE, TechMansou)
- [ ] v4.0 — Mémoire persistante
- [ ] v4.1 — Notifications & rappels
- [ ] v5.0 — App mobile native (PWA)

---

## 🔧 Comment mettre à jour JARVIS
1. Modifier `index.html` sur GitHub
2. Commit → Vercel redéploie automatiquement en ~30 secondes
3. Vérifier sur jarvis-mansou.vercel.app

---

*JARVIS — L'IA la plus avancée d'Abidjan 😄*
